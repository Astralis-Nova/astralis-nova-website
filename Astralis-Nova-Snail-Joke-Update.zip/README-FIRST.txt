Copy index.html and snail-sluggish-joke.png into the website root.
Suggested commit: Update Cosmic Chuckle with snail joke
